export { default } from "./Linker";
