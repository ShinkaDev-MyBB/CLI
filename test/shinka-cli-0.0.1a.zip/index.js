"use strict";

module.exports = {};
